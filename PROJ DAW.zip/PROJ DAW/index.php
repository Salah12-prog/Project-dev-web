<?php

if (isset($_POST['envoyer'])) {

    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    
    $connexion = new mysqli("localhost", "root", "", "mon_site");

    if ($connexion->connect_error) {
        die("Erreur de connexion");
    }

    
    $sql = "INSERT INTO messages (nom, email, message)
            VALUES ('$nom', '$email', '$message')";

    if ($connexion->query($sql) === TRUE) {
        echo "Message envoyé avec succès";
    } else {
        echo "Erreur";
    }

    $connexion->close();
}
?>
