<?php
session_start();

$conn = new mysqli("localhost", "root", "", "eshop");

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $_SESSION['user'] = $user['prenom'];
    header("Location: login.php");
} else {
    echo "Erreur de connexion";
}
?>